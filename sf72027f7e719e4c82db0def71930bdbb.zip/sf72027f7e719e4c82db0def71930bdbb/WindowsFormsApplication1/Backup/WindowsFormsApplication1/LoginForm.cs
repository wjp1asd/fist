﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (this.txtUsername.Text == "")
            {
                MessageBox.Show("请输入用户名");
                this.txtUsername.Focus();
                return;
            }
            else if (this.txtPassword.Text == "")
            {
                MessageBox.Show("请输入密码");
                this.txtPassword.Focus();
                return;
            }
            else
            {
                int power = 0;
                string role = this.comboBox1.SelectedItem.ToString();
                if (role == "学生")
                {
                    power = 1;
                }
                else
                {
                    power = 2;
                }



                string connectionString = @"server=.;database=examonline;Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);
                string sql = string.Format("select count(*) from dbo.student  where loginId='{0}' and password='{1}'and Power={2}", this.txtUsername.Text, this.txtPassword.Text, power);
                SqlCommand com = new SqlCommand(sql, con);
                con.Open();
                int count = int.Parse(com.ExecuteScalar().ToString());
                con.Close();

                if (count > 0)
                {
                    if (role == "教师")
                    {
                        GetStudentId(this.txtUsername.Text.Trim());
                        Form9 frm1 = new Form9();
                        frm1.Show();
                        this.Hide();
                    }
                    else
                    {
                        GetStudentId(this.txtUsername.Text.Trim());
                        MainForm frm = new MainForm();
                        frm.Show();
                        this.Hide();
                    }
                }
                else
                {
                    MessageBox.Show("失败");
                }

            }
        }
        private void GetStudentId(string loginId)
        {
             string connectionString = @"server=.;database=examonline;Integrated Security=True";
            SqlConnection con = new SqlConnection(connectionString);
            string sql = "select id from student where loginId='" + loginId .ToString()+"'";
            SqlCommand com = new SqlCommand(sql,con);
            con.Open();
           
            datahelp.StudentId = int.Parse(com.ExecuteScalar().ToString());
            con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void form1_Load(object sender, EventArgs e)
        {

        }

        
    }
}
