﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                Form10 frm = new Form10();
                frm.GetData(this.dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString(), this.dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString(),true);
                frm.Show();

            }
            else if (e.ColumnIndex == 1)
            {
                if (DialogResult.Yes == MessageBox.Show("是否删除科目:" + this.dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString(), "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {
                    MessageBox.Show("删除成功");
                }
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.dataGridView1.Visible = true;
            string connectionString = @"server=.;database=examonline;Integrated Security=True";
            SqlConnection con = new SqlConnection(connectionString);
            string sql = "select*from subject where subName like '%" + this.textBox1.Text + "%'";
            SqlCommand com = new SqlCommand(sql, con);
            SqlDataAdapter sda=new SqlDataAdapter (com);

            DataSet ds=new DataSet ();
            sda.Fill(ds,"sbujct");
            this.dataGridView1.DataSource=ds.Tables[0];

        }

        private void et()
        {
            throw new NotImplementedException();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form10 frm = new Form10();
            frm.GetData("", "", false);
            frm.Show();
        }
    }
}
