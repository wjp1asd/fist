﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {

        }

        public void GetData(string Id, string name,bool rt)
        {
            this.textBox1.Text = Id;
            this.textBox2.Text = name;
            this.textBox1.ReadOnly = rt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox1.ReadOnly)
            {
                //修改
            }
            else
            {
                //添加
            }
        }
    }
}
