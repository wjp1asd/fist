﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class fullScreen {

       
        public static void Main(System.Windows.Forms.UserControl form)
        {
            System.Drawing.Rectangle rect = System.Windows.Forms.Screen.PrimaryScreen.Bounds;
            int h = rect.Height; //高（像素）
            int w = rect.Width;  //宽（像素）
            Console.WriteLine("height:"+h);
            Console.WriteLine("weighgt:" + w);
            foreach (Control c in form.Controls)
            {
                // 1920*1080  为当前窗体设计的尺寸
                c.Size = new Size((int)(c.Width * w / 1920), (int)(c.Height * h / 1080));
                c.Location = new Point((int)(c.Left * w / 1920), (int)(c.Top * h / 1080));
                Single size = Convert.ToSingle(c.Font.Size * h / 1080);
                c.Font = new Font(c.Font.Name, size, c.Font.Style, c.Font.Unit);
            }
        }
        

    }

   

}
