﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Interop;
using System.Configuration;

namespace WindowsFormsApplication1
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
            this.flowLayoutPanel1.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (this.txtUsername.Text == "")
            {
                MessageBox.Show("请输入用户名");
                this.txtUsername.Focus();
                return;
            }
            else if (this.txtPassword.Text == "")
            {
                MessageBox.Show("请输入密码");
                this.txtPassword.Focus();
                return;
            }
            else
            {
      
                   
                int  power = 2;
                string connectionString = ConfigurationManager.AppSettings["sqlc"];
                SqlConnection con = new SqlConnection(connectionString);
                string sql = string.Format("select count(*) from dbo.student  where loginId='{0}' and password='{1}'and Power={2}", this.txtUsername.Text, this.txtPassword.Text, power);
                SqlCommand com = new SqlCommand(sql, con);
                con.Open();
                int count = int.Parse(com.ExecuteScalar().ToString());
                con.Close();
                MessageBox.Show(""+count); ;
                if (count > 0)
                {
                   
                       GetStudentId(this.txtUsername.Text.Trim());
                       AdminIndex a = new AdminIndex();
                      a.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("登录失败");
                }

            }
        }
        private void GetStudentId(string loginId)
        {
            string connectionString = ConfigurationManager.AppSettings["sqlc"];
            SqlConnection con = new SqlConnection(connectionString);
            string sql = "select id from student where loginId='" + loginId .ToString()+"'";
            SqlCommand com = new SqlCommand(sql,con);
            con.Open();
           
            datahelp.StudentId = int.Parse(com.ExecuteScalar().ToString());
            con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.flowLayoutPanel1.Hide();
        }

        private void form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.flowLayoutPanel1.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
          
        }
    }
}
