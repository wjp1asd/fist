﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class AdminIndex : Form
    {
        public AdminIndex()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            QuestionSet q = new QuestionSet();
            q.Show();
            this.Hide();
        }

        private void 管理员界面_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            GoalSet q = new GoalSet();
            q.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PeopleSet q = new PeopleSet();
            q.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            StudentSet q = new StudentSet();
            q.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ResultSet q = new ResultSet();
            q.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            GlobalSet q = new GlobalSet();
            q.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }
    }
}
